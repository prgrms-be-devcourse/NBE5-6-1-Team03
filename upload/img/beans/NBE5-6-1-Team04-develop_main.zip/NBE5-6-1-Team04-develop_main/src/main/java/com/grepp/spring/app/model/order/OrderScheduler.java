package com.grepp.spring.app.model.order;

import com.grepp.spring.app.model.order.code.OrderStatus;
import com.grepp.spring.app.model.order.dto.OrderDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
@RestController
public class OrderScheduler {

    private final OrderService orderService;

    @Scheduled(cron = "0 0 14 * * ?")
    public void scheduledProcessPendingOrders() {
        processPendingOrders();
    }

    // 테스트용 엔드포인트
    @GetMapping("/test/process-orders")
    public String testProcessOrders() {
        processPendingOrders();
        return "주문 처리가 완료되었습니다.";
    }

    public void processPendingOrders() {
        log.info("주문 일괄 처리 시작");

        List<OrderDto> pendingOrders = orderService.getPendingOrders();
        log.info("처리할 주문 수: {}", pendingOrders.size());

        for (OrderDto order : pendingOrders) {
            try {
                orderService.updateOrderStatus(order.getOrderId(), OrderStatus.PROCESSING);
                log.info("주문 상태 업데이트 완료: 주문번호 {}, 상태 PENDING -> PROCESSING", order.getOrderId());
            } catch (Exception e) {
                log.error("주문 상태 업데이트 실패: 주문번호 {}", order.getOrderId(), e);
            }
        }

        log.info("주문 일괄 처리 완료");
    }
}