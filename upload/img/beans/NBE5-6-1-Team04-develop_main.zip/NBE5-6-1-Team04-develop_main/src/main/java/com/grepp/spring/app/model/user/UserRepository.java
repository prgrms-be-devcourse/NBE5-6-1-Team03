package com.grepp.spring.app.model.user;



import org.springframework.stereotype.Repository;


@Repository
public interface UserRepository {

}
