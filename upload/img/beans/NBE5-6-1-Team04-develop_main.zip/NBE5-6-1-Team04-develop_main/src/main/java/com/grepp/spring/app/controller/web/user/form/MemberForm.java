package com.grepp.spring.app.controller.web.user.form;

public class MemberForm {

}
